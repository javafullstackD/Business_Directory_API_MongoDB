const mongoose = require('mongoose');
mongodb://127.0.0.1:27017/
mongoose.connect('mongodb://127.0.0.1:27017/mlambo-bussiness-api',()=>{
    console.log('connected to the db.....');
},e=> console.log(e.message));