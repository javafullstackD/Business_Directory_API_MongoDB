const mongoose = require('mongoose');


const BusinessSchema = new mongoose.Schema({
    business_name : {type: String, required: true},
    category: {type: mongoose.Schema.Types.ObjectId, ref: 'categories', required: true},
    city: { type: mongoose.Schema.Types.ObjectId, ref: 'cities', required: true}
},{timestamps: true});


module.exports = mongoose.model('businesses', BusinessSchema);