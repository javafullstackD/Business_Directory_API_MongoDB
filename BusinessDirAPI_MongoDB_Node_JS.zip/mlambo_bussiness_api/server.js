const express = require('express');
const body_parser = require('body-parser');
require('./config/db.config');


const cityRouter = require('./routes/city.route');
const categoryRouter = require('./routes/category.route');
const businessRouter = require('./routes/business.route');

const app = express();


app.use(body_parser.json())
app.use(body_parser.urlencoded({extended:true}));


app.use('/api/city', cityRouter);
app.use('/api/category', categoryRouter);
app.use('/api/business', businessRouter);


const PORT = process.env.PORT || 3000

app.get('/', (req, res)=>{
    res.status(200).json({msg:"Welcome to Bussiness Crude API"});
});


app.listen(PORT,()=>{
    console.log(`express server started at port http://localhost:${PORT}`);
});