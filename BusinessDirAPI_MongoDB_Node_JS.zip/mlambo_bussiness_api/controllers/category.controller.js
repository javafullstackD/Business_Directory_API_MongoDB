const categoryModel = require('../models/category.model');




exports.getCategories = (req, res)=>{
    categoryModel.find()
    .then(data=>{
        if(data.length == 0){
            res.status(200).json({msg: "Category data is empty"})
        }else{
            res.status(200).json({data});
        }
        
    }).catch(err=>res.send(err));
};


exports.createCategory = (req, res)=>{
    const category = new categoryModel(req.body);
    category.save()
    .then(data=> res.status(200).json({msg : "category was created", data}))
    .catch(err => res.status(500).json({msg:"error encountered while creating category in the database", err}));
};


exports.getCategoryById = (req, res)=>{
    categoryModel.findById(req.params.id)
    .then(category=>{
        if(!category){
            res.status(404).json({msg:'No category with that id'});
        }else{
            res.status(200).json(category)
        }
    }).catch(err=>{
        if(err.name == 'CastError'){
            res.status(404).json({ msg : 'Please check id type'})
        }else{
            res.status(500).json({msg : err})
        }
    });
};


exports.updateCategory = (req, res)=>{
    categoryModel.findByIdAndUpdate(req.params.id, req.body, {new : true})
    .then(data =>{
        if(!data){
            res.status(404).json({msg:'No city with that id'});
        }else{
            res.status(200).json(data)
        }}).catch(err=>{
            if(err.name == 'CastError'){
                res.status(404).json({ msg : 'Check  id type'})
            }else{
                res.status(500).json({msg : err})
            }
        });
};