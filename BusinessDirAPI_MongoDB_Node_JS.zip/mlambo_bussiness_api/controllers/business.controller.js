const Business = require('../models/business.model');
const {json}=require('body-parser')
const businessModel = require('../models/business.model')
const categoryModel = require('../models/category.model')
const City = require('../models/city.model')






exports.getBusiness = async (req, res)=>{
    Business.find()
    .populate('city', 'city_name')
    .populate('category', 'category_name')
    .exec()
    .then(data => {
        if(data.length == 0){
            res.status(200).json({msg: 'There is no businesse in this collection'})
        }else{
            res.status(200).json(data);
        }}).catch(err=>res.status(500).json({msg: 'Error while getting businesses', err}));   
};


exports.createBusiness = (req, res)=>{
    const business = new Business(req.body);
    business.save()
    .then(data=> res.status(200).json({msg : "business created", data}))
    .catch(err => res.status(500).json({msg:"error while creating business in the database", err}));
};


//get businesses by category//join by category
exports.getBusinessByCategory = (req, res)=>{
    categoryModel.find()
    .where('category_name')
    .equals(req.params.cat_name)
    .then(category =>{
        cat_id = category[0]._id;
        Business.find().where('category', '_id')
        .equals(cat_id)
        .select('business_name')
        .populate('category', 'category_name')
        .populate('city', 'city_name')
        .exec()
        .then(data=>{
            if(data.length == 0){
                res.status(200).json({msg: 'No busineses mapped with that category'})
            }else{
                res.status(200).json(data);
            }}).catch(err=>{
            res.status(500).json({msg: 'Error while while fetching business in that category'});
        });
    }).catch(err=>{
        res.status(404).json({ msg: 'category does not exists '});
    });
};

// exports.getBusinessByCategory = (req, res)=>{
    
//     Business.find().where('category', '_id')
//     .equals(req.params.id)
  
//     .select('business_name')
//     .populate('category_name')
//     .exec()
//     .then(data=> {
//         if(data.length == 0){
//             res.status(404).json({ msg : 'Category is not mapped to any Business'});
//         }else{
//             res.status(200).json(data);
//         }
//     })
//     .catch(err=> res.status(500).json({msg: 'error while getting businesses by category'}))
// };


exports.getBusinessById = (req, res)=>{
    Business.findById(req.params.id)
    .populate('city', 'city_name')
    .populate('category', 'category_name')
    .exec()
    .then(business=>{
        if(!business){
            res.status(404).json({msg:'business with that id was not found'});
        }else{
            res.status(200).json(business);
        }
    }).catch(err=>{
        if(err.name == 'CastError'){
            res.status(404).json({ msg : 'Please check your id type'})
        }else{
            res.status(500).json({msg : err})
        }
    });
};


exports.updateBusiness = (req, res)=>{
    Business.findByIdAndUpdate(req.params.id, req.body, {new : true})
    .then(data =>{
        if(!data){
            res.status(404).json({msg:'No Business with that id'});
        }else{
            res.status(200).json(data)
        }}).catch(err=>{
            if(err.name == 'CastError'){
                res.status(404).json({ msg : 'Please check id type'})
            }else{
                res.status(500).json({msg : err})
            }
        });
};

exports.getBusinessByCity = (req, res)=>{
    City.find()
    .where('city_name')
    .equals(req.params.city_name)
    .then(city =>{
        city_id = city[0]._id;
        Business.find().where('city', '_id')
        .equals(city_id)
        .select('business_name')
        .populate('category', 'category_name')
        .populate('city', 'city_name')
        .exec()
        .then(data=>{
            if(data.length == 0){
                res.status(200).json({msg: 'No busineses mapped with this city'});
            }else{
                res.status(200).json(data);
            }}).catch(err=>{
                res.status(500).json({msg: 'Error while while fetching business in that city'});
            });
    }).catch(err=>{
        res.status(404).json({msg:'City does not exist from collection'});
    });
}

exports.getBusinessByCategoryCity= (req, res)=>{
    City.find()
    .where('city_name')
    .equals(req.params.city)
    .then(city =>{
        categoryModel.find().where('category_name')
        .equals(req.params.cat)
        .then(category=>{
            city_id = city[0]._id;
            cat_id = category[0]._id;
            Business.find().where('city', '_id')
            .equals(city_id)
            .where('category', '_id')
            .equals(cat_id)
            .select('business_name')
            .populate('category', 'type')
            .populate('city', 'city_name')
            .exec()
            .then(data =>{
                if(data.length == 0){
                    res.status(200).json({msg:`No business mapped with ${req.params.city} city and ${req.params.cat} category`})
                }else{
                    res.status(200).json(data);
                }}).catch(err=>{
                res.status(500).json({msg:`error while getting businesses mapped to ${req.param.cat} category and ${req.param.city}`})
            });
        }).catch(err=>{
            res.status(404).json({msg: 'Category or City  does not exist from collection'});
        });
    }).catch(err=>{
        res.status(404).json(err);
    });
}

