const express = require('express');


const categoryController = require('../controllers/category.controller');


const router = express.Router();


router.get('/', categoryController.getCategories);
router.post('/', categoryController.createCategory);
router.get('/:id', categoryController.getCategoryById);
router.put('/:id', categoryController.updateCategory);

module.exports = router;