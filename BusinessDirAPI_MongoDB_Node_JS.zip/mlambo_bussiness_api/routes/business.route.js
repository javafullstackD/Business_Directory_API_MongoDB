const express = require('express');
const businessController = require('../controllers/business.controller');


const router = express.Router();



router.get('/', businessController.getBusiness);
router.post('/', businessController.createBusiness);
router.get('/:id', businessController.getBusinessById);
router.put('/:id', businessController.updateBusiness);
router.get('/businessBycategory/:cat_name', businessController.getBusinessByCategory);
router.get('/businessByCity/:city_name', businessController.getBusinessByCity);
router.get('/businessByCityCategory/:city/:cat', businessController.getBusinessByCategoryCity);


// router.get('/businessBycategory/:cat_name', businessController.getBusinessByCategory);
// router.get('/businessByCity/:city_name', businessController.getBusinessByCity);
// router.get('/businessByCityCategory/:city/:cat', businessController.getBusinessByCategoryCity);

module.exports = router;